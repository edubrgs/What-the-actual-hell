# WHAT THE ACTUAL HELL?

Projeto inicial 3D em Godot 4.4.1, com renderizador Compatibility.

## Gerar o executável Windows pela nuvem

O workflow `.github/workflows/build-windows.yml` compila o projeto no GitHub Actions e publica o arquivo `WHAT_THE_ACTUAL_HELL.exe` como artefato da execução.

No GitHub: abra a aba **Actions**, selecione **Build Windows EXE** e use **Run workflow**. Quando terminar, abra a execução e baixe o artefato `WHAT-THE-ACTUAL-HELL-Windows`.

Este é um protótipo inicial. O visual, os controles e os eventos ainda precisam de bastante desenvolvimento.
