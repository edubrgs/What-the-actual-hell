extends Node3D

var player: CharacterBody3D
var camera: Camera3D
var message_label: Label
var look_sensitivity := 0.0025
var move_speed := 4.0
var gravity := 18.0
var touch_origin := Vector2.ZERO
var move_vector := Vector2.ZERO
var look_touch_id := -1
var move_touch_id := -1
var event_timer := 0.0
var messages := [
	"A casa está silenciosa demais.",
	"Você ouviu isso? Provavelmente não.",
	"O gato está encarando você.",
	"Olá. Coma uma berinjela.",
	"Não existe cavalo nesta residência. Ainda."
]

func _ready() -> void:
	_build_world()
	_build_player()
	_build_hud()
	_show_message("Encontre uma saída. Ignore o gato.")

func _build_world() -> void:
	var world := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.22, 0.23, 0.27)
	environment.ambient_light_energy = 0.45
	world.environment = environment
	add_child(world)

	var floor_body := StaticBody3D.new()
	floor_body.name = "Floor"
	add_child(floor_body)
	var floor_mesh := MeshInstance3D.new()
	var floor_shape := BoxMesh.new()
	floor_shape.size = Vector3(16, 0.2, 16)
	floor_mesh.mesh = floor_shape
	floor_body.add_child(floor_mesh)
	var floor_collision := CollisionShape3D.new()
	var floor_box := BoxShape3D.new()
	floor_box.size = floor_shape.size
	floor_collision.shape = floor_box
	floor_body.add_child(floor_collision)
	floor_body.position.y = -0.1

	_add_wall(Vector3(0, 1.5, -8), Vector3(16, 3, 0.2))
	_add_wall(Vector3(0, 1.5, 8), Vector3(16, 3, 0.2))
	_add_wall(Vector3(-8, 1.5, 0), Vector3(0.2, 3, 16))
	_add_wall(Vector3(8, 1.5, 0), Vector3(0.2, 3, 16))

	var light := OmniLight3D.new()
	light.position = Vector3(0, 2.7, 0)
	light.light_energy = 1.1
	light.omni_range = 12
	add_child(light)

	# A temporary, deliberately strange cat built from simple shapes.
	var cat := Node3D.new()
	cat.name = "TheCat"
	cat.position = Vector3(2.2, 0, -2.0)
	add_child(cat)
	_add_cat_part(cat, Vector3(0, 1.0, 0), Vector3(0.55, 0.8, 0.35), Color(0.12, 0.1, 0.09))
	_add_cat_part(cat, Vector3(0, 1.65, 0), Vector3(0.48, 0.48, 0.42), Color(0.16, 0.13, 0.12))
	_add_cat_part(cat, Vector3(-0.16, 1.96, 0), Vector3(0.16, 0.34, 0.12), Color(0.16, 0.13, 0.12))
	_add_cat_part(cat, Vector3(0.16, 1.96, 0), Vector3(0.16, 0.34, 0.12), Color(0.16, 0.13, 0.12))
	_add_cat_part(cat, Vector3(-0.1, 1.7, -0.22), Vector3(0.06, 0.06, 0.04), Color(0.9, 0.1, 0.08))
	_add_cat_part(cat, Vector3(0.1, 1.7, -0.22), Vector3(0.06, 0.06, 0.04), Color(0.9, 0.1, 0.08))

func _add_wall(pos: Vector3, size: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	add_child(body)
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.18, 0.19, 0.21)
	mesh_instance.material_override = material
	body.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)

func _add_cat_part(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> void:
	var part := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	part.mesh = mesh
	part.position = pos
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	part.material_override = material
	parent.add_child(part)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.position = Vector3(0, 1, 4)
	add_child(player)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.height = 1.7
	capsule.radius = 0.32
	collision.shape = capsule
	player.add_child(collision)
	camera = Camera3D.new()
	camera.position.y = 0.55
	camera.current = true
	player.add_child(camera)

func _build_hud() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)
	message_label = Label.new()
	message_label.position = Vector2(18, 20)
	message_label.add_theme_font_size_override("font_size", 20)
	message_label.add_theme_color_override("font_color", Color.WHITE)
	message_label.text = ""
	canvas.add_child(message_label)
	var hint := Label.new()
	hint.text = "TOQUE E ARRASTE: olhar  |  LADO ESQUERDO: mover"
	hint.position = Vector2(18, 52)
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	canvas.add_child(hint)

func _show_message(value: String) -> void:
	if message_label:
		message_label.text = value

func _process(delta: float) -> void:
	event_timer += delta
	if event_timer > 18.0:
		event_timer = 0.0
		_show_message(messages[randi() % messages.size()])

func _physics_process(delta: float) -> void:
	if not player:
		return
	var direction := Vector3.ZERO
	var input_vector := move_vector
	if Input.is_key_pressed(KEY_W): input_vector.y -= 1
	if Input.is_key_pressed(KEY_S): input_vector.y += 1
	if Input.is_key_pressed(KEY_A): input_vector.x -= 1
	if Input.is_key_pressed(KEY_D): input_vector.x += 1
	direction = (player.transform.basis * Vector3(input_vector.x, 0, input_vector.y)).normalized()
	player.velocity.x = direction.x * move_speed
	player.velocity.z = direction.z * move_speed
	if not player.is_on_floor():
		player.velocity.y -= gravity * delta
	else:
		player.velocity.y = 0
	player.move_and_slide()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		_rotate_view(event.relative)
	elif event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.45 and move_touch_id == -1:
				move_touch_id = event.index
				touch_origin = event.position
			else:
				look_touch_id = event.index
		else:
			if event.index == move_touch_id:
				move_touch_id = -1
				move_vector = Vector2.ZERO
			if event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == move_touch_id:
			move_vector = (event.position - touch_origin).limit_length(70) / 70.0
		elif event.index == look_touch_id:
			_rotate_view(event.relative)

func _rotate_view(relative: Vector2) -> void:
	player.rotate_y(-relative.x * look_sensitivity)
	camera.rotate_x(-relative.y * look_sensitivity)
	camera.rotation.x = clamp(camera.rotation.x, -1.35, 1.35)
